README – Honey Multi-FX Synth

Version: 1.0
Format: FL Studio Patcher Preset (.fst)
Developer: Honeycomb Lab

Overview

	Honey is a multi-effect synth preset for FL Studio’s Patcher. It blends custom textures and effects into a 	single patch so you can drop it into 	any project and start crafting warm, experimental soundscapes in seconds.

Honey Multi-FX Synth/
│   Honey.fst          <- Main Patcher preset
│   Installer.bat      <- Easy one-click installer (Windows)
│   Demo.flp           <- Demo project with a melody made with Honey
│   honeycolor.exe     <- Sets custom console colors for installer
│   honey_pot.ico      <- Little honey pot icon
│   README.txt         <- That's me hehe
└───Assets/
        Grain.wav      <- Texture sample used in the preset
        Warmth.wav     <- Texture sample used in the preset

Installation
Automatic (Windows)
Run Installer.bat.

Follow the on-screen instructions to install the preset and assets to the correct FL Studio folder.

Add the installed Assets folder to FL Studio → Options → File Settings → Browser extra search folders so FL Studio always finds the samples.

Manual (All Platforms)
Copy the entire Honey Multi-FX Synth folder into:

Documents\Image-Line\FL Studio\Data\Plugin Presets\Patcher\
In FL Studio, add the Assets folder to Browser extra search folders under Options → File Settings.

Usage
In FL Studio, open Patcher in the Channel Rack.

Load Honey.fst from the Patcher preset list.

Play, tweak, and automate parameters on the Patcher Surface as desired.

Requirements
FL Studio 21+

Windows or macOS (preset and samples are cross-platform)

License
Royalty-free for commercial and personal music projects.

You may not redistribute, resell, or repackage Honey or its asset files.

Support
Website: https://www.honeycomblab.art/support.html

Email: contact@honeycomblab.art